#starting of iles
from flask import Flask
from backend.models import db

app=None

def setup_app():
    app=Flask(__name__)
    app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///household_services.sqlite3" #having connected to db
    db.init_app(app) # flask app connected to db(sql alchemy)
    app.app_context().push() #direct access to other modules
    app.debug=True
    print("Household service app is started...")


#call the setup
setup_app()

from backend.contollers import *

if __name__=="__main__":
    app.run()