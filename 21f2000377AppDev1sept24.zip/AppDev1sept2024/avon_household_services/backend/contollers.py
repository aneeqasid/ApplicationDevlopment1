# #App routes

from flask import Flask, render_template, request, session, url_for, redirect
from flask import abort
from .models import *
from flask import current_app as app
from datetime import datetime
from sqlalchemy import func, or_
from werkzeug.utils import secure_filename
from sqlalchemy.exc import SQLAlchemyError
import matplotlib.pyplot as plt
import base64, os

app.config['SECRET_KEY'] = os.urandom(24)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/login", methods=["GET","POST"])
def signin():
    if request.method=="POST":
        uname = request.form.get("username")
        pwd = request.form.get("password")
        
        # Direct password comparison
        usr = User.query.filter_by(email=uname, password=pwd).first()
        
        if usr:
            # Set session email and potentially other user info
            session['user_email'] = uname
            session['user_role'] = usr.role
            
            if usr.role == ROLE_ADMIN:
                return redirect(url_for("admin_dashboard", email=uname))
            elif usr.role == ROLE_CUSTOMER:
                return redirect(url_for("user_dashboard", email=uname))
            elif usr.role == ROLE_PROFESSIONAL:
                return redirect(url_for("professional_dashboard", email=uname))
        else:
            return render_template("login.html", msg="Invalid user credentials")

    return render_template("login.html", msg="")

@app.route("/signup", methods=["GET","POST"])
def signup():
    if request.method=="POST":
        uname = request.form.get("username")
        pwd = request.form.get("password")
        fname = request.form.get("fullname")
        address = request.form.get("address")
        pincode = request.form.get("pincode")

        # Check if user already exists
        existing_usr = Customer.query.filter_by(email=uname).first()
        if existing_usr:
            return render_template("signup.html", msg="Sorry, this mail already exists!")

        # Create a new customer instance 
        new_usr = Customer(
            email=uname, 
            password=pwd, 
            full_name=fname, 
            address=address, 
            pin_code=pincode, 
            role=ROLE_CUSTOMER
        ) 
        db.session.add(new_usr) 
        db.session.commit() 
        return render_template("login.html", msg="Registration successful, try login now")

    return render_template("signup.html", msg="")

@app.route("/professionalsignup", methods=["GET","POST"])
def professionalsignup():
    if request.method=="POST":
        uname = request.form.get("username")
        pwd = request.form.get("password")
        fname = request.form.get("fullname")
        address = request.form.get("address")
        pincode = request.form.get("pincode")
        desc = request.form.get("description")
        exp = request.form.get("experience")
        servicename = request.form.get("service_type")
        file=request.files["documents"]
        url=""
        if file.filename:
            file_name=secure_filename(file.filename)
            url='./uploaded_files'+fname+"_"+file_name #('./uploaded_files',file_name+"_"+uname)
            file.save(url)

        # Check if user already exists
        existing_usr = User.query.filter_by(email=uname).first()
        if existing_usr:
            return render_template("professionalsignup.html", msg="Sorry, this email already exists!")

        # Create a new professional instance 
        new_usr = Professional(
            email=uname, 
            password=pwd, 
            full_name=fname, 
            address=address, 
            pin_code=pincode, 
            experience=exp, 
            description=desc,
            service_type=servicename, 
            role=ROLE_PROFESSIONAL,
            documents=url
        ) 
        db.session.add(new_usr) 
        db.session.commit() 
        return render_template("login.html", msg="Registration successful, try login now")

    return render_template("professionalsignup.html", msg="")

@app.route("/admin/<email>")
def admin_dashboard(email):
    user = User.query.filter_by(email=email, role=0).first()
    user_email = request.args.get('email')
    user_name = request.args.get('full_name')
    if not user:
        abort(404)
    services = get_services()
    professionals = get_professionals()  
    service_requests = get_service_requests()  
    pending_professionals = Professional.query.filter_by(is_verified=False).all()
    verified_professionals = Professional.query.filter_by(is_verified=True).all()
    customers = User.query.filter_by(role=1).all()

    return render_template(
        "admin_dashboard.html",
        email=email,
        services=services,
        professionals=verified_professionals,
        service_requests=service_requests,
        user=user,
        user_email=user_email,
        pending_professionals=pending_professionals,
        customers=customers,
        


    )

@app.route("/user/<email>")
def user_dashboard(email):
    user = Customer.query.filter_by(email=email).first()
    user_email = request.args.get('email')
    if not user:
        abort(404)
    services = get_services()
    service_requests = ServiceRequest.query.filter_by(customer_id=user.id).all()
    
    return render_template("user_dashboard.html", 
                           email=email, 
                           services=services, 
                           user=user, 
                           service_requests=service_requests)

@app.route("/professional/<email>")
def professional_dashboard(email):
    user = Professional.query.filter_by(email=email).first()
    if not user:
        abort(404)

    today_services = ServiceRequest.query.filter(
        ServiceRequest.professional_id == user.id,
        ServiceRequest.service_status.in_([
            SERVICE_STATUS_REQUESTED, 
            SERVICE_STATUS_ASSIGNED, 
            SERVICE_STATUS_IN_PROGRESS
        ])
    ).all()

    closed_services = ServiceRequest.query.filter(
        ServiceRequest.professional_id == user.id,
        ServiceRequest.service_status == SERVICE_STATUS_CLOSED
    ).all()

    return render_template(
        "professional_dashboard.html",
        user=user,
        today_services=today_services,
        closed_services=closed_services,
        email=user.email
    )


@app.route("/new_service/<email>", methods=["POST","GET"])
def new_service(email):
    user = User.query.filter_by(email=email, role=ROLE_ADMIN).first()
    if not user:
        abort(404)
    if request.method=="POST":
        sname = request.form.get("name")
        base_price = request.form.get("base_price")
        desc = request.form.get("description")
        time_required = request.form.get("time_required")
        
        new_service = Service(
            name=sname,
            base_price=float(base_price),
            description=desc,
            time_required=float(time_required)
        )
        db.session.add(new_service)
        db.session.commit()
        return redirect(url_for("admin_dashboard", email=email, user=user))

    return render_template("new_service.html", email=email, user=user)



@app.route("/edit_service/<int:id>/<email>", methods=["POST","GET"])
def edit_service(id, email):
    user = User.query.filter_by(email=email).first()
    if not user:
        abort(404)
    serv = get_service_for_edit(id)

    
    if request.method == "POST":
        
        serv.id = request.form.get("id", serv.id)
        serv.name = request.form.get("name", serv.name)
        serv.base_price = float(request.form.get("base_price", serv.base_price))
        serv.time_required = request.form.get("time_required", serv.time_required)
        serv.description = request.form.get("description", serv.description)
        
        db.session.commit()
        
        return redirect(url_for("admin_dashboard", user=user, email=email))
    return render_template("edit_service.html", service=serv, user=user, email=email)




@app.route("/delete_service/<int:id>/<email>", methods=["POST","GET"])
def delete_service(id,email):
    user = User.query.filter_by(email=email).first()
    if not user:
        abort(404)
    serv = get_service_for_edit(id) #using the same func again
    db.session.delete(serv)
    db.session.commit()
    return redirect(url_for("admin_dashboard",user=user, email=email))

@app.route('/admin/verify_professional/<int:id>', methods=['POST'])
def verify_professional(id):
    professional = Professional.query.get_or_404(id)
    professional.is_verified = True
    db.session.commit()

    return redirect(url_for('admin_dashboard', email=request.form['email']))

@app.route("/book_service/<int:service_id>/<email>")
def book_service(service_id, email):
    user = Customer.query.filter_by(email=email).first()
    if not user:
        abort(404)
    service = Service.query.get_or_404(service_id)
    professionals = Professional.query.filter_by(service_type=service.name, is_verified=True).all()
    return render_template("book_service.html", service=service, professionals=professionals, user=user)

@app.route("/request_service/<email>", methods=["POST"])
def request_service(email):
    user = Customer.query.filter_by(email=email).first()
    if not user:
        abort(404)

    service_id = request.form.get("service_id")
    professional_id = request.form.get("professional_id")
    customer_remarks = request.form.get("customer_remarks")


    new_request = ServiceRequest(
        service_id=service_id,
        customer_id=user.id,
        professional_id=professional_id,
        service_status=SERVICE_STATUS_REQUESTED,
        customer_remarks=customer_remarks
    )
    
    db.session.add(new_request)
    db.session.commit()
    
    return redirect(url_for('user_dashboard', email=email))


from datetime import datetime

@app.route("/edit_service_request/<int:request_id>/<email>", methods=["GET", "POST"])
def edit_service_request(request_id, email):
    user = Customer.query.filter_by(email=email).first()
    if not user:
        abort(404)

    service_request = ServiceRequest.query.get_or_404(request_id)

    if service_request.customer_id != user.id:
        abort(403)  

    if request.method == "POST":
        
        # Update customer remarks
        service_request.customer_remarks = request.form.get("customer_remarks", service_request.customer_remarks)
        
        # Handle date of request
        request_date_str = request.form.get("date_of_request")
        if request_date_str:
            service_request.date_of_request = datetime.strptime(request_date_str, "%Y-%m-%d")
        
        # Handle date of completion if applicable
        completion_date_str = request.form.get("date_of_completion")
        if completion_date_str:
            service_request.date_of_completion = datetime.strptime(completion_date_str, "%Y-%m-%d")
        
        db.session.commit()
    
        return redirect(url_for('user_dashboard', email=email))
    
        
    services = get_services()
    all_service_requests = ServiceRequest.query.filter_by(customer_id=user.id).all()

    return render_template(
        "edit_service_request.html", 
        service_request=service_request,
        user=user,
        email=email,
        services=services,
        service_requests=all_service_requests
    )

@app.route("/professional/update_service_request/<int:request_id>/<action>", methods=["POST"])
def update_service_request(request_id, action):
    service_request = ServiceRequest.query.get_or_404(request_id)
    
    # Get email from session or service request
    email = session.get('user_email')
    
    # If no email in session, try to get from the professional associated with the service request
    if not email and service_request.professional:
        email = service_request.professional.email
    
    # If still no email, try to get from the professional
    if not email:
        professional = Professional.query.get(service_request.professional_id)
        if professional:
            email = professional.email
    
    # If absolutely no email found, redirect to login
    if not email:
        return redirect(url_for('signin'))
    
    # Validate professional ownership
    professional = Professional.query.filter_by(email=email).first()
    
    # Additional validation
    if not professional or service_request.professional_id != professional.id:
        # Fallback to a safe redirect
        return redirect(url_for('signin'))
    
    # Prevent actions on closed services
    if service_request.service_status == SERVICE_STATUS_CLOSED:
        return redirect(url_for('professional_dashboard', email=email))
    
    try:
        # Update service request status based on action
        if action == "accept":
            service_request.service_status = SERVICE_STATUS_IN_PROGRESS
            service_request.date_of_start = datetime.now()
        
        elif action == "reject":
            service_request.service_status = SERVICE_STATUS_CANCELED
        
        elif action == "complete":
            service_request.service_status = SERVICE_STATUS_CLOSED
            service_request.date_of_completion = datetime.now()
        
        db.session.commit()
        
        return redirect(url_for('professional_dashboard', email=email))
    
    except SQLAlchemyError as e:
        db.session.rollback()
        # Log the error if possible
        return redirect(url_for('professional_dashboard', email=email))
# @app.route("/professional/update_service_request/<int:request_id>/<action>", methods=["POST"])
# def update_service_request(request_id, action):
#     service_request = ServiceRequest.query.get_or_404(request_id)
#     email = session.get('user_email')

#     # Validate professional ownership
#     professional = Professional.query.filter_by(email=email).first()
#     if not professional or service_request.professional_id != professional.id:
#         return redirect(url_for('professional_dashboard', email=email))

#     # Prevent actions on closed services or completed services
#     if service_request.service_status == SERVICE_STATUS_CLOSED:
#         return redirect(url_for('professional_dashboard', email=email))

#     try:
#         if action == "accept":
#             service_request.service_status = SERVICE_STATUS_IN_PROGRESS
#             service_request.date_of_start = datetime.now()
        
#         elif action == "reject":
#             service_request.service_status = SERVICE_STATUS_CANCELED
        
#         elif action == "complete":
#             service_request.service_status = SERVICE_STATUS_CLOSED
#             service_request.date_of_completion = datetime.now()
        
#         db.session.commit()
        
#         return redirect(url_for('professional_dashboard', email=email))
    
#     except SQLAlchemyError as e:
#         db.session.rollback()
#         # Log the error
#         return redirect(url_for('professional_dashboard', email=email))

# @app.route("/professional/update_service_request/<int:request_id>/<action>", methods=["POST"])
# def update_service_request(request_id, action):
#     service_request = ServiceRequest.query.get_or_404(request_id)
#     user_email = session.get('user_email')

#     # Validate professional ownership
#     if not service_request.professional or service_request.professional.email != session.get('user_email'):
#         return redirect(url_for('professional_dashboard'))

#     # Prevent actions on closed services or completed services
#     if service_request.service_status == SERVICE_STATUS_CLOSED:
#         return redirect(url_for('professional_dashboard', email=service_request.professional.email))

#     if action == "accept":
#         if service_request.service_status in [SERVICE_STATUS_REQUESTED, SERVICE_STATUS_ASSIGNED]:
#             service_request.service_status = SERVICE_STATUS_IN_PROGRESS
#             service_request.date_of_start = datetime.now()

#     elif action == "reject":
#         if service_request.service_status in [SERVICE_STATUS_REQUESTED, SERVICE_STATUS_ASSIGNED]:
#             service_request.service_status = SERVICE_STATUS_REQUESTED
#             service_request.professional_id = None

#     elif action == "close":
#         if service_request.service_status in [SERVICE_STATUS_REQUESTED, SERVICE_STATUS_ASSIGNED, SERVICE_STATUS_IN_PROGRESS]:
#             service_request.service_status = SERVICE_STATUS_CLOSED
#             service_request.date_of_completion = datetime.now()

            # Ensure a review record exists
    #         existing_review = Review.query.filter_by(service_request_id=service_request.id).first()
    #         if not existing_review:
    #             new_review = Review(
    #                 service_request_id=service_request.id,
    #                 rating=0,
    #                 comments="",
    #                 created_at=datetime.now()
    #             )
    #             db.session.add(new_review)

    # db.session.commit()
    # return redirect(url_for('professional_dashboard', email=user_email))
# @app.route("/professional/update_service_request/<int:request_id>/<action>", methods=["POST"])
# def update_service_request(request_id, action):
#     service_request = ServiceRequest.query.get_or_404(request_id)
    
#     try:
#         if not service_request.professional or service_request.professional.email != session.get('user_email'):
#             return redirect(url_for('professional_dashboard'))
        
#         if action == "close":
#             # Allow closing from multiple statuses
#             if service_request.service_status in [SERVICE_STATUS_REQUESTED, SERVICE_STATUS_ASSIGNED, SERVICE_STATUS_IN_PROGRESS]:
#                 service_request.service_status = SERVICE_STATUS_CLOSED
#                 service_request.date_of_completion = datetime.now()
                
#                 # Ensure a review record exists
#                 existing_review = Review.query.filter_by(service_request_id=service_request.id).first()
#                 if not existing_review:
#                     new_review = Review(
#                         service_request_id=service_request.id,
#                         rating=0,
#                         comments="",
#                         created_at=datetime.now()
#                     )
#                     db.session.add(new_review)
#             else:
#                 return redirect(url_for('professional_dashboard', email=service_request.professional.email))
            
#         elif action == "accept":
#             if service_request.service_status in [SERVICE_STATUS_CLOSED, SERVICE_STATUS_IN_PROGRESS]:
#                 return redirect(url_for('professional_dashboard', email=service_request.professional.email))
            
#             service_request.service_status = SERVICE_STATUS_IN_PROGRESS
#             service_request.date_of_start = datetime.now()
        
#         elif action == "reject":
#             if service_request.service_status in [SERVICE_STATUS_CLOSED, SERVICE_STATUS_IN_PROGRESS]:
#                 return redirect(url_for('professional_dashboard', email=service_request.professional.email))
            
#             service_request.service_status = SERVICE_STATUS_REQUESTED
#             service_request.professional_id = None
        
#         elif action == "close":
#             if service_request.service_status != SERVICE_STATUS_IN_PROGRESS:
#                 return redirect(url_for('professional_dashboard', email=service_request.professional.email))
            
#             service_request.service_status = SERVICE_STATUS_CLOSED
#             service_request.date_of_completion = datetime.now()
            
#             existing_review = Review.query.filter_by(service_request_id=service_request.id).first()
#             if not existing_review:
#                 new_review = Review(
#                     service_request_id=service_request.id,
#                     rating=0,
#                     comments="",
#                     created_at=datetime.now()
#                 )
#                 db.session.add(new_review)
        
#         else:
#             return redirect(url_for('professional_dashboard', email=service_request.professional.email))
        
#         db.session.commit()
#         return redirect(url_for('professional_dashboard', email=service_request.professional.email))
    
#     except SQLAlchemyError:
#         db.session.rollback()
#         return redirect(url_for('professional_dashboard', email=service_request.professional.email))
    
#     except Exception:
#         db.session.rollback()
#         return redirect(url_for('professional_dashboard', email=service_request.professional.email))


# @app.route("/professional/update_service_request/<int:request_id>/<action>", methods=["POST"])
# def update_service_request(request_id, action):
#     # Find the service request
#     service_request = ServiceRequest.query.get_or_404(request_id)
    
#     try:
#         if action == "accept":
#             # Update status to assigned or in progress
#             service_request.service_status = SERVICE_STATUS_ASSIGNED
            
#             # Optional: You might want to add a timestamp or other logic
#             # service_request.professional_response = "Service request accepted"
#             service_request.service_status = SERVICE_STATUS_IN_PROGRESS
#             service_request.date_of_start = datetime.now()
        
#         elif action == "reject":
#             # Update status back to requested (so it can be assigned to another professional)
#             service_request.service_status = SERVICE_STATUS_REQUESTED
            
#             # Clear the professional assignment
#             service_request.professional_id = None
#             # service_request.professional_response = "Service request rejected"
        
#         # Commit changes to the database
#         db.session.commit()
        
#         # Redirect back to professional dashboard
#         return redirect(url_for('professional_dashboard', email=service_request.professional.email))
    
#     except Exception as e:
#         # Handle any errors
#         db.session.rollback()
#         # You might want to add error logging here
#         return "An error occurred", 500

    
@app.route("/cancel_service_request/<int:request_id>/<email>", methods=["POST", "GET"])
def cancel_service_request(request_id, email):
    # Fetch the logged-in user
    user = Customer.query.filter_by(email=email).first()
    if not user:
        abort(404)

    # Locate the service request
    service_request = ServiceRequest.query.get_or_404(request_id)

    # Check if the service request belongs to the logged-in customer
    if service_request.customer_id != user.id:
        abort(403)  # Forbidden if the request doesn't belong to the user

    try:
        # Update the service request status to 'canceled'
        service_request.service_status = SERVICE_STATUS_CANCELED
        db.session.commit()
        
        # Redirect back to the user's dashboard
        return redirect(url_for("user_dashboard", email=email))
    except Exception as e:
        # Rollback in case of an error
        db.session.rollback()
        return "An error occurred while canceling the service request.", 500
        
# @app.route("/cancel_service_request/<int:request_id>/<email>")
# def cancel_service_request(request_id, email):
#     user = Customer.query.filter_by(email=email).first()
#     if not user:
#         abort(404)

#     service_request = ServiceRequest.query.get_or_404(request_id)

#     if service_request.customer_id != user.id:
#         abort(403)  # Forbidden if the request doesn't belong to the user

#     if service_request.service_status == SERVICE_STATUS_REQUESTED:
#         db.session.delete(service_request)
#         db.session.commit()

#     return redirect(url_for('user_dashboard', email=email))

@app.route("/professional_response/<int:request_id>/<email>", methods=["GET", "POST"])
def professional_response(request_id, email):
    professional = Professional.query.filter_by(email=email).first()
    if not professional:
        abort(404)

    service_request = ServiceRequest.query.get_or_404(request_id)

    if service_request.professional_id != professional.id:
        abort(403)  # Forbidden if the request isn't assigned to this professional

    if request.method == "POST":
        service_request.professional_response = request.form.get("professional_response")
        db.session.commit()
        return redirect(url_for('professional_dashboard', email=email))

    return render_template("professional_response.html", service_request=service_request, professional=professional)

@app.route('/admin/block_professional/<int:id>', methods=['POST'])
def block_professional(id):
    professional = Professional.query.get_or_404(id)
    professional.is_blocked = True
    db.session.commit()

    return redirect(url_for('admin_dashboard', email=request.form['email']))

@app.route('/admin/unblock_professional/<int:id>', methods=['POST'])
def unblock_professional(id):
    professional = Professional.query.get_or_404(id)
    professional.is_blocked = False
    db.session.commit()

    return redirect(url_for('admin_dashboard', email=request.form['email']))





@app.route('/admin/block_customer/<int:id>', methods=['POST'])
def block_customer(id):
    customer = Customer.query.get_or_404(id)
    customer.is_blocked = True
    db.session.commit()
    return redirect(url_for('admin_dashboard', email=request.form.get('email')))


@app.route('/admin/unblock_customer/<int:id>', methods=['POST'])
def unblock_customer(id):
    customer = Customer.query.get_or_404(id)
    customer.is_blocked = False
    db.session.commit()
    return redirect(url_for('admin_dashboard', email=request.form.get('email')))

@app.route("/admin_summary")
def admin_summary():
    user = User.query.filter_by(role=ROLE_ADMIN).first()
    # Get the summary
    summary = admin_summary()
    
    return render_template("admin_summary.html", summary=summary, user=user)














# Supporting functions
def get_services():
    services = Service.query.all()
    return services


def get_service_requests():
    service_requests = ServiceRequest.query.all()
    return service_requests

def get_professionals():
    professionals = Professional.query.all()
    return professionals

def get_service_for_edit(id):
    service = Service.query.filter_by(id=id).first()
    return service


def get_services_summary():
    service_req=get_service_requests()
    summary={}
    for s in service_req:
        summary[s.service.name]=s.id
    x_names=list(summary.keys())
    y_id = list(summary.values())
    plt.bar(x_names,y_id,color="blue",width=0.4)
    plt.title("Customer Summary")
    plt.xlabel("ServiceName")
    plt.ylabel("Requests made")



def admin_summary():
    # Professionals Summary
    verified_professionals = Professional.query.filter_by(is_verified=True).count()
    pending_professionals = Professional.query.filter_by(is_verified=False).count()
    
    # Customers Summary
    total_customers = Customer.query.count()
    blocked_customers = Customer.query.filter_by(is_blocked=True).count()
    active_customers = total_customers - blocked_customers
    
    # Service Requests Summary
    request_statuses = db.session.query(
        ServiceRequest.service_status, 
        func.count(ServiceRequest.id).label('status_count')
    ).group_by(ServiceRequest.service_status).all()

    # Create figure
    plt.figure(figsize=(15, 5))
    
    # Professionals Pie Chart
    plt.subplot(1, 3, 1)
    plt.pie(
        [verified_professionals, pending_professionals], 
        labels=['Verified', 'Pending'], 
        autopct='%1.1f%%',
        colors=['green', 'orange']
    )
    plt.title('Professional Status')
    
    # Customers Pie Chart
    plt.subplot(1, 3, 2)
    plt.pie(
        [active_customers, blocked_customers], 
        labels=['Active', 'Blocked'], 
        autopct='%1.1f%%',
        colors=['blue', 'red']
    )
    plt.title('Customer Status')
    
    # Service Requests Bar Chart
    plt.subplot(1, 3, 3)
    plt.bar(
        [status.service_status for status in request_statuses], 
        [status.status_count for status in request_statuses],
        color='purple'
    )
    plt.title('Service Requests by Status')
    plt.xlabel('Request Status')
    plt.ylabel('Number of Requests')
    plt.xticks(rotation=45, ha='right')
    
    plt.tight_layout()
    
    # Save plot directly to a file
    plt.savefig('./static/admin_summary.png')
    plt.close()

    # Prepare summary dictionary
    summary = {
        'professionals': {
            'verified': verified_professionals,
            'pending': pending_professionals,
            'total': verified_professionals + pending_professionals
        },
        'customers': {
            'total': total_customers,
            'active': active_customers,
            'blocked': blocked_customers,
        },
        'service_requests': {
            'status_breakdown': {
                status.service_status: status.status_count 
                for status in request_statuses
            }
        },
        'chart_image': 'admin_summary.png'
    }
    
    return summary

@app.route("/search/<email>", methods=["GET", "POST"])
def search(email):
    user = User.query.filter_by(email=email).first()
    if not user:
        abort(404)

    if request.method == "POST":
        search_txt = request.form.get("search_txt")
        by_professionals = search_by_professionals(search_txt)
        by_location = search_by_location(search_txt)

        if by_professionals:
            return render_template("admin_dashboard.html", 
                                   professionals=by_professionals, 
                                   email=email, 
                                   user=user)
        
        elif by_location:
            return render_template("admin_dashboard.html", 
                                   professionals=by_location, 
                                   email=email, 
                                   user=user)
    
    return redirect(url_for('admin_dashboard', email=email))

def search_by_professionals(search_txt):
    professionals=Professional.query.filter(Professional.full_name.ilike(f"{search_txt}")).all()
    return professionals

def search_by_location(search_txt):
    professionals = User.query.filter(
        User.role == ROLE_PROFESSIONAL,  # Ensure only professionals are queried
        User.address.ilike(f"%{search_txt}%")  # Use % wildcards for partial matching
    ).all()
    return professionals

@app.route("/user/search/<email>", methods=["GET", "POST"])
def user_search(email):
    user = Customer.query.filter_by(email=email).first()
    if not user:
        abort(404)

    if request.method == "POST":
        search_txt = request.form.get("search_txt")
        
        # Search services by name or description
        services_by_name = search_services_by_name(search_txt)
        
        # Search professionals by location or service type
        professionals_by_location = search_professionals_by_location(search_txt)
        
        # Combine and filter services based on found professionals
        filtered_services = []
        if professionals_by_location:
            for professional in professionals_by_location:
                services = Service.query.filter_by(name=professional.service_type).all()
                filtered_services.extend(services)
        
        # If no services found by professionals, use services by name
        if not filtered_services:
            filtered_services = services_by_name
        
        return render_template(
            "user_dashboard.html", 
            user=user, 
            services=filtered_services,
            search_query=search_txt
        )
    
    return redirect(url_for('user_dashboard', email=email))

def search_services_by_name(search_txt):
    """Search services by name or description"""
    services = Service.query.filter(
        or_(
            Service.name.ilike(f"%{search_txt}%"),
            Service.description.ilike(f"%{search_txt}%")
        )
    ).all()
    return services

def search_professionals_by_location(search_txt):
    """Search professionals by location, service type, or name"""
    professionals = Professional.query.filter(
        or_(
            Professional.address.ilike(f"%{search_txt}%"),
            Professional.service_type.ilike(f"%{search_txt}%"),
            Professional.full_name.ilike(f"%{search_txt}%")
        ),
        Professional.is_verified == True  # Only verified professionals
    ).all()
    return professionals

