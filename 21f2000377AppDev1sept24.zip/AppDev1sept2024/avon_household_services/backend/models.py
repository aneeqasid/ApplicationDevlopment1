# #data models

from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

db = SQLAlchemy()

# User Roles constants
ROLE_CUSTOMER = 1 
ROLE_PROFESSIONAL = 2 
ROLE_ADMIN = 0

# Service Status Constants
SERVICE_STATUS_REQUESTED = 'Requested'
SERVICE_STATUS_ASSIGNED = 'Assigned'
SERVICE_STATUS_IN_PROGRESS = 'In Progress'
SERVICE_STATUS_CLOSED = 'Closed'
SERVICE_STATUS_CANCELED = 'canceled'

# User base model (for Customer and Professional)
class User(db.Model):
    __tablename__ = "user"
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String, unique=True, nullable=False)
    password = db.Column(db.String, nullable=False)
    role = db.Column(db.Integer, nullable=False)  # 1 for customer, 2 for professional, 0 for admin
    full_name = db.Column(db.String, nullable=False)
    address = db.Column(db.String, nullable=False)
    pin_code = db.Column(db.Integer, nullable=False)
    is_blocked = db.Column(db.Boolean, default=False)  # To block/unblock users
    created_at = db.Column(db.DateTime, default=datetime.now)

    __mapper_args__ = {
        'polymorphic_identity': 'user',
        'polymorphic_on': role
    }

# Customer model extending User
class Customer(User):
    __tablename__ = "customer"
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)
    

    __mapper_args__ = {
        'polymorphic_identity': ROLE_CUSTOMER,
    }

# Professional model extending User
class Professional(User):
    __tablename__ = "professional"
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)
    service_type = db.Column(db.String, nullable=False)
    date_created = db.Column(db.DateTime, default=datetime.now)
    experience = db.Column(db.Integer, nullable=False)
    description = db.Column(db.String)
    documents = db.Column(db.String, nullable=True, default="None") #this will store the url of the uploaded documents
    is_verified = db.Column(db.Boolean, default=False)  # Indicates if verified by admin

    __mapper_args__ = {
        'polymorphic_identity': ROLE_PROFESSIONAL,
    }



# ServiceRequest model
class ServiceRequest(db.Model):
    __tablename__ = "service_request"
    id = db.Column(db.Integer, primary_key=True)
    service_id = db.Column(db.Integer, db.ForeignKey('service.id'), nullable=False)
    customer_id = db.Column(db.Integer, db.ForeignKey('customer.id'), nullable=False)
    professional_id = db.Column(db.Integer, db.ForeignKey('professional.id'), nullable=True)
    date_of_request = db.Column(db.DateTime, default=datetime.now)
    date_of_completion = db.Column(db.DateTime, nullable=True)
    preferred_date = db.Column(db.DateTime, nullable=True)
    preferred_time = db.Column(db.String(20), nullable=True)
    service_status = db.Column(
        db.Enum(
            SERVICE_STATUS_REQUESTED,
            SERVICE_STATUS_ASSIGNED,
            SERVICE_STATUS_IN_PROGRESS,
            SERVICE_STATUS_CLOSED,
            SERVICE_STATUS_CANCELED,
            name='service_status_types'
        ), 
        default=SERVICE_STATUS_REQUESTED
    )
    customer_remarks = db.Column(db.Text)
    professional_response = db.Column(db.Text)

    customer = db.relationship("Customer", cascade="all,delete", backref='service_requests', lazy=True)
    professional = db.relationship("Professional", cascade="all,delete",  backref='service_requests', lazy=True)
    service = db.relationship("Service",  cascade="all,delete", backref='service_requests', lazy=True)

# Service model
class Service(db.Model):
    __tablename__ = "service"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), unique=True, nullable=False)
    base_price = db.Column(db.Float, nullable=False)
    time_required = db.Column(db.String(50), nullable=True)  
    description = db.Column(db.Text)

#Review model
class Review(db.Model):
    __tablename__ = "review"
    id = db.Column(db.Integer, primary_key=True)
    service_request_id = db.Column(db.Integer, db.ForeignKey('service_request.id'), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5 stars
    comments = db.Column(db.Text)
    created_at = db.Column(db.DateTime, default=datetime.now)

    service_request = db.relationship("ServiceRequest",  cascade="all,delete", backref='review')

# Admin model (no registration needed,data is added manually into db)
class Admin(User):
    __tablename__ = "admin"
    id = db.Column(db.Integer, db.ForeignKey('user.id'), primary_key=True)

    __mapper_args__ = {
        'polymorphic_identity': ROLE_ADMIN,
    }
