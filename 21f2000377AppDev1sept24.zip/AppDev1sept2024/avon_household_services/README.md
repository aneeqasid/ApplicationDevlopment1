# avon_household_services

#Steps for setup github

1. Install git cli on windows
2. Create git account using IITM mail id
3. Create new repo on github.com as pvt
4. Clone the repo on local system
5. Use VSCode to start implementation
